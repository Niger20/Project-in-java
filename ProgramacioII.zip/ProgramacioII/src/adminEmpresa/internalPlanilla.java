package adminEmpresa;

import java.awt.Color;
import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import static javax.swing.WindowConstants.HIDE_ON_CLOSE;
import javax.swing.table.DefaultTableModel;

public class internalPlanilla extends JInternalFrame implements ActionListener{

    Color colorPanel = new Color(139, 178, 201);
    DefaultTableModel modeloTabla;
    JTable tablaDatos;
    JScrollPane panelTabla;
    Color colorTxtBox = new Color(224, 224, 224);
    Color colorBtn = new Color(104, 100, 102);
    JButton btnMostrarFich;

    public internalPlanilla() throws IOException {

        this.setLayout(null);
        this.setTitle("PLANILLA");
        this.setResizable(false);
        this.setClosable(true);
        this.setBounds(0, 0, 1000, 500);
        this.setDefaultCloseOperation(HIDE_ON_CLOSE);

        this.setBackground(colorPanel);
        tablaDatos();
        botones();
    }
    
    public void botones(){
        
        btnMostrarFich = new JButton("MOSTRAR FICHERO DE PLANILLA");
        btnMostrarFich.setBounds(300, 400, 400, 50);
        btnMostrarFich.addActionListener(this);
        btnMostrarFich.setBackground(colorBtn);
        btnMostrarFich.setForeground(Color.white);
        this.add(btnMostrarFich);
        
    }

    public void tablaDatos() {

        modeloTabla = new DefaultTableModel() {

            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        modeloTabla.addColumn("Nombre");
        modeloTabla.addColumn("Puesto");
        modeloTabla.addColumn("Salario bruto");
        modeloTabla.addColumn("INSS");
        modeloTabla.addColumn("IR");
        modeloTabla.addColumn("Salario Neto");
        modeloTabla.addColumn("INSS Patronal");

        tablaDatos = new JTable(modeloTabla);
        tablaDatos.setGridColor(Color.black);
        tablaDatos.setBackground(colorTxtBox);
        tablaDatos.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        panelTabla = new JScrollPane(tablaDatos);
        panelTabla.setBounds(30, 20, 920, 350);

        this.add(panelTabla);

    }

    public int contarLineasFich() throws FileNotFoundException, IOException {

        File prod = new File("empleados.txt");
        FileReader fr = new FileReader(prod);
        BufferedReader br = new BufferedReader(fr);
        String cadena = br.readLine();

        int lineCount = 1;
        String line = br.readLine();
        while (line != null) {
            lineCount++;
            line = br.readLine();
        }
        return lineCount;

    }

    public void datosTabla() {

        modeloTabla.setRowCount(0);
        
        try {
            File prod = new File("empleados.txt");
            FileReader fr = new FileReader(prod);
            BufferedReader br = new BufferedReader(fr);
            String cadena = br.readLine();
            
            while (cadena != null) {

                String reg[] = cadena.split(",");
                String nombre, salario, puesto, strINSS, strIR, strSalarioNeto, strInssPat;
                int inss, IR, salMenosinss, salarioNeto, InssPat;
                nombre = reg[0];
                salario = reg[2];
                puesto = reg[3];

                inss = (int) ((int) Integer.parseInt(salario) * 0.07);
                salMenosinss = Integer.parseInt(salario) - inss;
                IR = this.calcularIR(salMenosinss);
                salarioNeto = Integer.parseInt(salario) - (inss + IR);
                strSalarioNeto = "" + salarioNeto;
                strIR = "" + IR;

                int lineCount = contarLineasFich();
                
                if (lineCount <= 50) {

                    InssPat = (int) (0.215 * Integer.parseInt(salario));

                } else {

                    InssPat = (int) (0.225 * Integer.parseInt(salario));

                }

                strINSS = "" + inss;
                strInssPat = "" + InssPat;

                String regMod[] = new String[7];
                regMod[0] = nombre;
                regMod[1] = puesto;
                regMod[2] = salario;
                regMod[3] = strINSS;
                regMod[4] = strIR;
                regMod[5] = strSalarioNeto;
                regMod[6] = strInssPat;

                modeloTabla.addRow(regMod);
                cadena = br.readLine();

            }
            br.close();
            fr.close();

        } catch (IOException e) {

        }

        try {
            this.eliminarFichero();
        } catch (IOException ex) {
            Logger.getLogger(internalPlanilla.class.getName()).log(Level.SEVERE, null, ex);
        }

        try {
            this.exportarFichero();
        } catch (IOException ex) {
            Logger.getLogger(internalPlanilla.class.getName()).log(Level.SEVERE, null, ex);
        }

        
        
    }

    //METODO PARA EXPORTAR AL FICHERO LOS DATOS DE LA TABLA
    public void exportarFichero() throws IOException {

        File planilla = new File("planilla.txt");
        FileWriter fw = new FileWriter(planilla, true);
        BufferedWriter bw = new BufferedWriter(fw);
        String cadena = "NOMBRE|PUESTO|SALARIO|INSS|IR|SALARIO NETO|INSS PATRONAL|\n";

        try {

            for (int fila = 0; fila < modeloTabla.getRowCount(); fila++) {
                for (int columna = 0; columna < modeloTabla.getColumnCount(); columna++) {

                    cadena = cadena + modeloTabla.getValueAt(fila, columna) + "|";
                }
                cadena = cadena + "\n";

            }
            bw.write(cadena);
            bw.close();
            fw.close();

        } catch (Exception e) {
        }

    }

    // METODO PARA BORRAR FICHERO PARA ACTUALIZAR DATOS
    public void eliminarFichero() throws IOException {

        File archivo = new File("planilla.txt");
        if (archivo.delete()) {
            System.out.println("");
        } else {
            System.out.println("");
        }

    }

    // METODO PARA REALIZAR CALCULO DEL IR
    public int calcularIR(int salarioSinINSS) {

        int salarioAnual = salarioSinINSS * 12;
        int IR, temp, temp1;

        if (salarioAnual <= 100000) {
            IR = 0;
            return IR;
        } else if (salarioAnual > 100000 && salarioAnual <= 200000) {

            temp = salarioAnual - 100000;
            temp1 = (int) ((int) temp * 0.15);
            IR = temp1 / 12;
            return IR;

        } else if (salarioAnual > 200000 && salarioAnual <= 350000) {

            temp = salarioAnual - 200000;
            temp1 = (int) ((int) temp * 0.2) + 15000;
            IR = temp1 / 12;
            return IR;

        } else if (salarioAnual > 350000 && salarioAnual <= 500000) {

            temp = salarioAnual - 350000;
            temp1 = (int) ((int) temp * 0.25) + 45000;
            IR = temp1 / 12;
            return IR;

        } else if (salarioAnual > 500000) {

            temp = salarioAnual - 500000;
            temp1 = (int) ((int) temp * 0.3) + 82500;
            IR = temp1 / 12;
            return IR;

        }
        return 0;

    }
    
    public void mostrarFichero(){
        
        try {
            File archivo = new File("planilla.txt");
            
            if (!Desktop.isDesktopSupported()) {
                JOptionPane.showMessageDialog(null, "NO SOPORTA ESTA FUNCION");
            }
            
            Desktop desktop = Desktop.getDesktop();
            if (archivo.exists()) {
                desktop.open(archivo);
            }else{
                JOptionPane.showMessageDialog(null, "NO EXISTE EL FICHERO");
            }
            
        } catch (Exception e) {
        }
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
         if (e.getSource() == btnMostrarFich) {
            this.mostrarFichero();
        }
    
    }

}
