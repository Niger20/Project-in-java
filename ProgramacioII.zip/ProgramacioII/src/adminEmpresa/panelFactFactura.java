package adminEmpresa;

import java.awt.Color;
import java.awt.Desktop;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

public class panelFactFactura extends JPanel implements ActionListener {

    Color colorPanel = new Color(139, 178, 201);
    JLabel codFactura, fechaFactura;
    JButton btnExportar, btnEliminar, btnEliminar_;
    JTextField codFact, fechaFact;
    Font fuente = new Font("Arial", Font.BOLD, 13);
    Color colorBtnCancel = new Color(146, 12, 12);
    Color colorBtnPrint = new Color(46, 146, 10);
    Color colorBtn = new Color(174, 174, 174);
    int cod;
    boolean error;
    File factura;
    FileWriter fw;
    BufferedWriter bw;
    String cadena, precio, cant, subtot, iva, total, prod, nombre, ruc, telefono, productosAnad, codigoFactura, cadenaResumen;
    panelFactProd panProd = new panelFactProd();
    panelFactCliente panCliet = new panelFactCliente();
    String prodAr[] = new String[1000];
    String subtotAr[] = new String[1000];
    String ivaAr[] = new String[1000];
    String cantAr[] = new String[1000];
    String totAr[] = new String[1000];

    public panelFactFactura() throws IOException {

        this.setLayout(null);
        this.setBackground(colorPanel);
        this.setBounds(350, 0, 600, 175);
        this.setBorder(new TitledBorder(new EtchedBorder(), "Datos Factura"));

        try {
            importCodFact();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(panelFactFactura.class.getName()).log(Level.SEVERE, null, ex);
        }
        labels();
        txtboxs();
        botones();
        resetContProdAdd();

    }

    public void labels() {

        codFactura = new JLabel("Codigo de Factura: ");
        codFactura.setBounds(50, 20, 130, 30);

        codFactura.setFont(fuente);

        fechaFactura = new JLabel("Fecha: ");
        fechaFactura.setBounds(50, 60, 130, 30);
        fechaFactura.setFont(fuente);

        this.add(fechaFactura);
        this.add(codFactura);

    }

    public void txtboxs() {

        codFact = new JTextField();
        codFact.setBounds(215, 20, 100, 30);
        ponerCodigo();

        fechaFact = new JTextField();
        fechaFact.setBounds(215, 60, 100, 30);
        fechaFact.setEditable(false);

        //CONFIGURACION FECHA
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date fechaActual = new Date();
        String Fecha = dateFormat.format(fechaActual);
        fechaFact.setText(Fecha);

        this.add(fechaFact);
        this.add(codFact);

    }

    public void ponerCodigo() {
        int longi = codigoFactura.length() - 1;
        String code = "" + codigoFactura.charAt(longi);
        cod = (Integer.parseInt(code)) + 1;
        genCodFact();
        codFact.setEditable(false);
    }

    public void importCodFact() throws FileNotFoundException {

        File data = new File("codigoFactura.txt");
        FileReader fr = new FileReader(data);
        BufferedReader br = new BufferedReader(fr);

        try {

            this.codigoFactura = br.readLine();

            br.close();
            fr.close();

        } catch (IOException e) {

        }

    }

    public void botones() {

        Image iconobtnExportar = new ImageIcon("src/Iconos/correcto.png").getImage();
        ImageIcon iconobtnExportarEsc = new ImageIcon(iconobtnExportar.getScaledInstance(30, 30, Image.SCALE_SMOOTH));

        Image iconobtnEliminar = new ImageIcon("src/Iconos/eliminar.png").getImage();
        ImageIcon iconobtnEliminarEsc = new ImageIcon(iconobtnEliminar.getScaledInstance(30, 30, Image.SCALE_SMOOTH));

        btnExportar = new JButton("Imprimir Factura", iconobtnExportarEsc);
        btnExportar.setBackground(Color.white);
        btnExportar.setForeground(colorBtnPrint);
        btnExportar.setBorder(BorderFactory.createLineBorder(colorBtnPrint, 2));
        btnExportar.addActionListener(this);
        btnExportar.setBounds(375, 20, 200, 50);

        btnEliminar = new JButton("Eliminar Facturas", iconobtnEliminarEsc);
        btnEliminar.setBackground(Color.white);
        btnEliminar.setForeground(colorBtnCancel);
        btnEliminar.setBorder(BorderFactory.createLineBorder(colorBtnCancel, 2));
        btnEliminar.addActionListener(this);
        btnEliminar.setBounds(375, 100, 200, 50);

        btnEliminar_ = new JButton("Eliminar Facturas", iconobtnEliminarEsc);
        btnEliminar_.setBackground(Color.white);
        btnEliminar_.setForeground(colorBtnCancel);
        btnEliminar_.setBorder(BorderFactory.createLineBorder(colorBtnCancel, 2));
        btnEliminar_.addActionListener(this);
        btnEliminar_.setBounds(375, 100, 200, 50);
        btnEliminar_.setVisible(false);

        this.add(btnEliminar);
        this.add(btnEliminar_);
        this.add(btnExportar);
    }

    public void genCodFact() {

        if (cod < 10) {
            String codigo = "0000" + cod;
            codFact.setText(codigo);
        } else if (cod < 100) {
            String codigo = "000" + cod;
            codFact.setText(codigo);
        } else if (cod < 1000) {

            String codigo = "00" + cod;
            codFact.setText(codigo);

        } else {
            String codigo = "" + cod;
            codFact.setText(codigo);
        }

        cod = cod + 1;

    }

    public void importDataFact() {

        try {
            File data = new File("datosfact.txt");
            FileReader fr = new FileReader(data);
            BufferedReader br = new BufferedReader(fr);
            String cadena = br.readLine();

            String reg[] = cadena.split(",");
            prod = reg[0];
            cant = reg[1];
            subtot = reg[2];
            iva = reg[3];
            total = reg[4];
            productosAnad = reg[5];

            br.close();
            fr.close();

        } catch (IOException e) {

        }

    }

    public void exportarCodFact() throws IOException {

        File productos = new File("codigoFactura.txt");
        FileWriter fw = new FileWriter(productos, true);
        BufferedWriter bw = new BufferedWriter(fw);
        String cadena = codFact.getText();

        try {

            bw.write(cadena);
            bw.close();
            fw.close();

        } catch (Exception e) {
        }

    }

    public void deleteCodFact() {

        File archivo = new File("codigoFactura.txt");
        if (archivo.delete()) {
            System.out.println("");
        } else {
            System.out.println("");
        }

    }

    public void importDataAcum() {

        try {
            File data = new File("datosFactAcum.txt");
            FileReader fr = new FileReader(data);
            BufferedReader br = new BufferedReader(fr);
            String cadena = br.readLine();
            int i = 0;

            while (cadena != null) {

                String reg[] = cadena.split(",");

                prodAr[i] = reg[0];
                subtotAr[i] = reg[2];
                ivaAr[i] = reg[3];
                cantAr[i] = reg[1];
                totAr[i] = reg[4];

                cadenaResumen = cadenaResumen + prodAr[i] + "," + cantAr[i] + "\n";
                cadena = br.readLine();

                i = i + 1;
            }
            br.close();
            fr.close();

        } catch (IOException e) {

        }

    }

    public void importDataFact2() {

        try {
            File data = new File("datosfact2.txt");
            FileReader fr = new FileReader(data);
            BufferedReader br = new BufferedReader(fr);
            String cadena = br.readLine();

            String reg[] = cadena.split(",");
            nombre = reg[0];
            ruc = reg[1];
            telefono = reg[2];

            br.close();
            fr.close();

        } catch (IOException e) {

        }

    }

    public void genFactura() throws IOException {
        importDataFact();
        deleteCodFact();
        exportarCodFact();

        File resumenFactura = new File("RESUMENFACTURAS.txt");
        FileWriter rfFW = new FileWriter(resumenFactura, true);
        BufferedWriter rfBW = new BufferedWriter(rfFW);
        cadenaResumen = "";

        if (productosAnad == null || "1".equals(productosAnad) || productosAnad.isEmpty()) {
            importDataFact2();
            String code = codFact.getText();
            factura = new File("FACTURA" + code + ".txt");
            fw = new FileWriter(factura, true);
            bw = new BufferedWriter(fw);
            cadena = "";

            try {

                cadena = "------------------DATOS FACTURA----------------\n"
                        + "CODIGO: " + this.codFact.getText()
                        + "\nFECHA: " + this.fechaFact.getText()
                        + "\n------------------DATOS CLIENTE----------------\n"
                        + "NOMBRE: " + nombre
                        + "\nRUC: " + ruc
                        + "\nTELEFONO: " + telefono
                        + "\n------------------DATOS PRODUCTO----------------\n"
                        + "PRODUCTO: " + prod
                        + "\nCANTIDAD: " + cant
                        + "\nSUBTOTAL: " + subtot
                        + "\nIVA: " + iva
                        + "\n---------------------- TOTAL --------------------\n"
                        + "TOTAL: " + total;
                cadenaResumen = prod + "," + cant + "\n";
                rfBW.write(cadenaResumen);
                bw.write(cadena);
            } catch (Exception e) {
            }

            bw.close();
            fw.close();
            rfBW.close();
            rfFW.close();
        } else {

            importDataAcum();
            importDataFact2();
            String code = codFact.getText();
            factura = new File("FACTURA" + code + ".txt");
            fw = new FileWriter(factura, true);
            bw = new BufferedWriter(fw);
            cadena = "";

            // ADD datos de productos anadidos
            prod = "";
            int subtot_ = 0;
            int tot_ = 0;
            int iva_ = 0;
            int i = 0;
            while (prodAr[i] != null && subtotAr[i] != null && ivaAr[i] != null && totAr[i] != null) {
                prod = prod + prodAr[i] + "( " + cantAr[i] + " )" + ",";
                subtot_ = subtot_ + Integer.parseInt(subtotAr[i]);
                tot_ = tot_ + Integer.parseInt(totAr[i]);
                iva_ = iva_ + Integer.parseInt(ivaAr[i]);
                i = i + 1;
            }

            try {

                cadena = "------------------DATOS FACTURA----------------\n"
                        + "CODIGO: " + this.codFact.getText()
                        + "\nFECHA: " + this.fechaFact.getText()
                        + "\n------------------DATOS CLIENTE----------------\n"
                        + "NOMBRE: " + nombre
                        + "\nRUC: " + ruc
                        + "\nTELEFONO: " + telefono
                        + "\n------------------DATOS PRODUCTO----------------\n"
                        + "PRODUCTO (CANTIDAD): " + prod
                        + "\nSUBTOTAL: " + subtot_
                        + "\nIVA: " + iva_
                        + "\n---------------------- TOTAL --------------------\n"
                        + "TOTAL: " + tot_;
                bw.write(cadena);
                rfBW.write(cadenaResumen);
            } catch (Exception e) {
            }

            bw.close();
            fw.close();

            rfBW.close();
            rfFW.close();
        }

    }

    public void mostrarFichero() {

        try {
            String codigo_ = codFact.getText();
            File archivo = new File("FACTURA" + codigo_ + ".txt");

            if (!Desktop.isDesktopSupported()) {
                JOptionPane.showMessageDialog(null, "NO SOPORTA ESTA FUNCION");
            }

            Desktop desktop = Desktop.getDesktop();
            if (archivo.exists()) {
                desktop.open(archivo);
            } else {
                JOptionPane.showMessageDialog(null, "NO EXISTE EL FICHERO");
            }

        } catch (Exception e) {
        }

    }

    public void resetContProdAdd() throws IOException {
        File cont = new File("contDat.txt");
        FileWriter fw = new FileWriter(cont, true);
        BufferedWriter bw = new BufferedWriter(fw);
        String cadena = "";

        try {

            cadena = "1";

            bw.write(cadena);
            bw.close();
            fw.close();

        } catch (Exception e) {
        }
    }

    public void deleteFactura() throws FileNotFoundException {
        String codigoFactura_ = codFact.getText();
        File archivo = new File("FACTURA" + codigoFactura_ + ".txt");
        if (archivo.delete()) {
            JOptionPane.showMessageDialog(null, "FACTURA ELIMINADA CORRECTAMENTE");
        } else {
            JOptionPane.showMessageDialog(null, "FACTURA NO EXISTENTE");
        }
        codFact.setEditable(false);
        importCodFact();

    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == btnExportar) {

            try {
                this.genFactura();
                panProd.deleteFicheroAcum();
                JOptionPane.showMessageDialog(null, "FACTURA GENERADA CORRECTAMENTE");
                this.mostrarFichero();
            } catch (IOException ex) {

            }

            this.genCodFact();

            try {
                this.resetContProdAdd();
            } catch (IOException ex) {
                Logger.getLogger(panelFactFactura.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

        if (e.getSource() == btnEliminar) {

            codFact.setText("");
            codFact.setEditable(true);
            btnExportar.setEnabled(false);
            btnEliminar_.setVisible(true);
            btnEliminar.setVisible(false);

        }

        if (e.getSource() == btnEliminar_) {

            try {
                deleteFactura();
            } catch (FileNotFoundException ex) {
                Logger.getLogger(panelFactFactura.class.getName()).log(Level.SEVERE, null, ex);
            }
            ponerCodigo();

            btnEliminar_.setVisible(false);
            btnEliminar.setVisible(true);
            btnExportar.setEnabled(true);

        }

    }

}
