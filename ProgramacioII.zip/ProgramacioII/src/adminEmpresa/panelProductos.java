package adminEmpresa;

import java.awt.Color;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

public class panelProductos extends Panel implements ActionListener {

    JLabel codProducto, nombProducto, precioProducto, desProducto, codProveedor, cantProducto;
    JTextField txtcodProducto, txtnombProducto, txtprecioProducto, txtdesProducto, txtcodProveedor, txtcantProducto;
    JTable tablaDatos;
    DefaultTableModel modeloTabla;
    JScrollPane panelTabla;
    JButton btnGuardar, btnSalir, btnExpt, btnNuevoRegistro, btnEditarRegistro, btnEliminarRegistro;

    Color colorPanel = new Color(131, 156, 181);
    Color colorTxtBox = new Color(224, 224, 224);
    Color colorBtn = new Color(104, 100, 102);
    Color colorBtnCancel = new Color(146, 12, 12);

    public panelProductos() {

        this.setLayout(null);
        this.setSize(600, 600);
        this.setBackground(colorPanel);

        labels();
        txtBoxs();
        botones();
        tablaDatos();
        datosTabla();

    }

    //METODO PARA CONFIGURAR Y ANADIR LABELS AL PANEL
    public void labels() {

        codProducto = new JLabel("Código de producto: ");
        codProducto.setBounds(70, 50, 150, 30);
        codProducto.setForeground(Color.white);
        this.add(codProducto);

        nombProducto = new JLabel("Nombre del producto: ");
        nombProducto.setBounds(70, 100, 150, 30);
        nombProducto.setForeground(Color.white);
        this.add(nombProducto);

        precioProducto = new JLabel("Precio: ");
        precioProducto.setBounds(70, 150, 150, 30);
        precioProducto.setForeground(Color.white);
        this.add(precioProducto);

        desProducto = new JLabel("Descripción: ");
        desProducto.setBounds(70, 200, 150, 30);
        desProducto.setForeground(Color.white);
        this.add(desProducto);

        codProveedor = new JLabel("Código proveedor: ");
        codProveedor.setBounds(70, 250, 150, 30);
        codProveedor.setForeground(Color.white);
        this.add(codProveedor);

        cantProducto = new JLabel("Cantidad Producto: ");
        cantProducto.setBounds(70, 300, 150, 30);
        cantProducto.setForeground(Color.white);
        this.add(cantProducto);

    }

    //METODO PARA CONFIGURAR Y ANADIR TXTFIELDS AL PANEL
    public void txtBoxs() {

        txtcodProducto = new JTextField();
        txtcodProducto.setBounds(250, 50, 200, 35);
        //txtNomb.addFocusListener(new validacionDa());
        txtcodProducto.setBackground(colorTxtBox);
        txtcodProducto.setEditable(false);
        this.add(txtcodProducto);

        txtnombProducto = new JTextField();
        txtnombProducto.setBounds(250, 100, 200, 35);
        //txtNomb.addFocusListener(new validacionDa());
        txtnombProducto.setBackground(colorTxtBox);
        txtnombProducto.setEditable(false);
        this.add(txtnombProducto);

        txtprecioProducto = new JTextField();
        txtprecioProducto.setBounds(250, 150, 200, 35);
        //txtNomb.addFocusListener(new validacionDa());
        txtprecioProducto.setBackground(colorTxtBox);
        txtprecioProducto.setEditable(false);
        this.add(txtprecioProducto);

        txtdesProducto = new JTextField();
        txtdesProducto.setBounds(250, 200, 200, 35);
        //txtNomb.addFocusListener(new validacionDa());
        txtdesProducto.setBackground(colorTxtBox);
        txtdesProducto.setEditable(false);
        this.add(txtdesProducto);

        txtcodProveedor = new JTextField();
        txtcodProveedor.setBounds(250, 250, 200, 35);
        //txtNomb.addFocusListener(new validacionDa());
        txtcodProveedor.setBackground(colorTxtBox);
        txtcodProveedor.setEditable(false);
        this.add(txtcodProveedor);

        txtcantProducto = new JTextField();
        txtcantProducto.setBounds(250, 300, 200, 35);
        //txtNomb.addFocusListener(new validacionDa());
        txtcantProducto.setBackground(colorTxtBox);
        txtcantProducto.setEditable(false);
        this.add(txtcantProducto);

    }

    //METODO PARA CONFIGURAR Y ANADIR BOTONES AL PANEL
    public void botones() {

        btnExpt = new JButton("Exportar");
        btnExpt.addActionListener(this);
        btnExpt.setBounds(95, 350, 100, 30);
        btnExpt.setBackground(colorBtn);
        btnExpt.setForeground(Color.WHITE);
        btnExpt.setVisible(false);
        //this.add(btnExpt);

        btnSalir = new JButton("Cancelar");
        btnSalir.addActionListener(this);
        btnSalir.setBounds(265, 350, 150, 30);
        btnSalir.setBackground(colorBtnCancel);
        btnSalir.setForeground(Color.WHITE);
        btnSalir.setVisible(false);
        this.add(btnSalir);

        btnGuardar = new JButton("Guardar");
        btnGuardar.addActionListener(this);
        btnGuardar.setBounds(95, 350, 150, 30);
        btnGuardar.setBackground(colorBtn);
        btnGuardar.setForeground(Color.WHITE);
        btnGuardar.setVisible(false);
        this.add(btnGuardar);

        btnEditarRegistro = new JButton("Editar Registro");
        btnEditarRegistro.addActionListener(this);
        btnEditarRegistro.setBounds(180, 350, 140, 30);
        btnEditarRegistro.setBackground(colorBtn);
        btnEditarRegistro.setForeground(Color.WHITE);
        this.add(btnEditarRegistro);

        btnNuevoRegistro = new JButton("Nuevo Registro");
        btnNuevoRegistro.addActionListener(this);
        btnNuevoRegistro.setBounds(30, 350, 140, 30);
        btnNuevoRegistro.setBackground(colorBtn);
        btnNuevoRegistro.setForeground(Color.WHITE);
        this.add(btnNuevoRegistro);

        btnEliminarRegistro = new JButton("Eliminar Registro");
        btnEliminarRegistro.addActionListener(this);
        btnEliminarRegistro.setBounds(330, 350, 140, 30);
        btnEliminarRegistro.setBackground(colorBtnCancel);
        btnEliminarRegistro.setForeground(Color.WHITE);
        this.add(btnEliminarRegistro);

    }

    //METODO PARA LIMPIAR PANTALLA
    public void limpiarPantalla() {
        txtcodProducto.setText("");
        txtnombProducto.setText("");
        txtprecioProducto.setText("");
        txtdesProducto.setText("");
        txtcodProveedor.setText("");
        txtcantProducto.setText("");

    }

    //METODO PARA CONFIGURAR Y ANADIR TABLA AL PANEL
    public void tablaDatos() {

        modeloTabla = new DefaultTableModel() {

            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        modeloTabla.addColumn("Cod prodcuto");
        modeloTabla.addColumn("Nomb producto");
        modeloTabla.addColumn("Precio producto");
        modeloTabla.addColumn("Des producto");
        modeloTabla.addColumn("Cod proveedor");
        modeloTabla.addColumn("Cant producto");

        tablaDatos = new JTable(modeloTabla);
        tablaDatos.setGridColor(Color.black);
        tablaDatos.setBackground(colorTxtBox);
        tablaDatos.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        panelTabla = new JScrollPane(tablaDatos);
        panelTabla.setBounds(500, 50, 500, 350);

        this.add(panelTabla);

    }

    //METODO PARA VALIDAR QUE NO HAYA NINGUN CAMPO VACIO
    public boolean validarNoVacio() {

        //, , ;
        if (!txtcodProducto.getText().isEmpty() && !txtnombProducto.getText().isEmpty() && !txtprecioProducto.getText().isEmpty() && !txtdesProducto.getText().isEmpty() && !txtcodProveedor.getText().isEmpty() && !txtcantProducto.getText().isEmpty()) {
            return true;
        } else {
            return false;
        }

    }

    //METODO QUE CAMBIA LA PANTALLA CUANDO SE PRECIONA EL BOTON NUEVO REGISTRO
    public void nuevoRegistro() throws IOException {

        btnGuardar.setVisible(true);
        btnSalir.setVisible(true);
        btnExpt.setVisible(true);

        btnNuevoRegistro.setVisible(false);
        btnEditarRegistro.setVisible(false);
        btnEliminarRegistro.setVisible(false);

        txtcodProducto.setEditable(true);
        txtnombProducto.setEditable(true);
        txtprecioProducto.setEditable(true);
        txtdesProducto.setEditable(true);
        txtcodProveedor.setEditable(true);
        txtcantProducto.setEditable(true);

    }

    //RETORNA LA PANTALLA A SUS VALORES INICIALES
    public void retornarValoresDefecto() {

        txtcodProducto.setText("");
        txtcodProducto.setEditable(false);
        txtnombProducto.setText("");
        txtnombProducto.setEditable(false);
        txtprecioProducto.setText("");
        txtprecioProducto.setEditable(false);
        txtdesProducto.setText("");
        txtdesProducto.setEditable(false);
        txtcodProveedor.setText("");
        txtcodProveedor.setEditable(false);
        txtcantProducto.setText("");

        btnGuardar.setVisible(false);
        btnExpt.setVisible(false);
        btnSalir.setVisible(false);

        txtcantProducto.setEditable(false);
        btnNuevoRegistro.setVisible(true);
        btnEditarRegistro.setVisible(true);
        btnEliminarRegistro.setVisible(true);

    }

    //METODO PARA GUARDAR DATOS EN LA TABLA
    public void guardarDatosTabla() {

        String codProd, nombProd, preProd, desProd, codProv, cantProd;
        codProd = txtcodProducto.getText();
        nombProd = txtnombProducto.getText();
        preProd = txtprecioProducto.getText();
        desProd = txtdesProducto.getText();
        codProv = txtcodProveedor.getText();
        cantProd = txtcantProducto.getText();

        String[] datosProducto = new String[6];
        datosProducto[0] = codProd;
        datosProducto[1] = nombProd;
        datosProducto[2] = preProd;
        datosProducto[3] = desProd;
        datosProducto[4] = codProv;
        datosProducto[5] = cantProd;

        modeloTabla.addRow(datosProducto);

    }

    public boolean avanzarOcancelar() {
        int opcion = JOptionPane.showConfirmDialog(null, "¿Estás seguro, los datos que no se hayan exportado se eliminaran?", "Confirmación", JOptionPane.OK_CANCEL_OPTION);
        if (opcion == JOptionPane.OK_OPTION) {
            return true;
        } else {
            return false;
        }
    }

    //METODO PARA EXPORTAR AL FICHERO LOS DATOS DE LA TABLA
    public void exportarFichero() throws IOException {

        File productos = new File("productos.txt");
        FileWriter fw = new FileWriter(productos, true);
        BufferedWriter bw = new BufferedWriter(fw);
        String cadena = "";

        try {

            for (int fila = 0; fila < modeloTabla.getRowCount(); fila++) {
                for (int columna = 0; columna < modeloTabla.getColumnCount(); columna++) {

                    cadena = cadena + modeloTabla.getValueAt(fila, columna) + ",";
                }
                cadena = cadena + "\n";

            }
            bw.write(cadena);
            bw.close();
            fw.close();

        } catch (Exception e) {
        }

    }

    // IMPORTAR DESDE EL FICHERO LOS DATOS DE LA TABLA
    public void datosTabla() {

        try {
            File prod = new File("productos.txt");
            FileReader fr = new FileReader(prod);
            BufferedReader br = new BufferedReader(fr);
            String cadena = br.readLine();

            while (cadena != null) {

                String reg[] = cadena.split(",");
                modeloTabla.addRow(reg);
                cadena = br.readLine();

            }
            br.close();
            fr.close();

        } catch (IOException e) {

        }

    }

    //VALIDAR QUE CIERTOS CAMPOS UNICAMENTE CONTENGAN NUMEROS
    public boolean validarNumeros() {
        // , , ;
        try {
            int code = Integer.parseInt(txtcodProducto.getText());
            int codeProv = Integer.parseInt(txtcodProveedor.getText());
            int cantProd = Integer.parseInt(txtcantProducto.getText());
            double precio = Double.parseDouble(txtprecioProducto.getText());
            return true;
        } catch (Exception e) {
            return false;
        }

    }

    //VALIDAR QUE CIERTOS CAMPOS UNICAMENTE CONTENGAN LETRAS
    public boolean validarLetras(String cadena) {

        for (int i = 0; i < cadena.length(); i++) {

            char caracter = cadena.toUpperCase().charAt(i);
            int valorASCII = (int) caracter;

            if (valorASCII != 165 && (valorASCII < 65 || valorASCII > 90) && valorASCII != 32) {
                return false;
            }

        }
        return true;

    }

// METODO PARA BORRAR FICHERO PARA ACTUALIZAR DATOS
    public void eliminarFichero() throws IOException {

        File archivo = new File("productos.txt");
        if (archivo.delete()) {
            System.out.println("");
        } else {
            System.out.println("");
        }

    }

    // METODO PARA ELIMINAR UN REGISTRO
    public void eliminarRegistro() throws IOException {

        if (tablaDatos.getSelectedRow() != -1) {

            modeloTabla.removeRow(tablaDatos.getSelectedRow());

            this.eliminarFichero();
            this.exportarFichero();

            JOptionPane.showMessageDialog(null, "REGISTRO ELIMINADO CORRECTAMENTE");

        } else {

            JOptionPane.showMessageDialog(null, "FAVOR SELECCIONAR EL REGISTRO A ELIMINAR");

        }

    }

    // METODO PARA MODIFICAR UN REGISTRO
    public void editarRegistro() throws IOException {

        if (tablaDatos.getSelectedRow() != -1) {

            String codProd, nombProd, precProd, desProd, codProv, cantProd;
            codProd = "" + tablaDatos.getValueAt(tablaDatos.getSelectedRow(), 0);
            nombProd = "" + tablaDatos.getValueAt(tablaDatos.getSelectedRow(), 1);
            precProd = "" + tablaDatos.getValueAt(tablaDatos.getSelectedRow(), 2);
            desProd = "" + tablaDatos.getValueAt(tablaDatos.getSelectedRow(), 3);
            codProv = "" + tablaDatos.getValueAt(tablaDatos.getSelectedRow(), 4);
            cantProd = "" + tablaDatos.getValueAt(tablaDatos.getSelectedRow(), 5);

            txtcodProducto.setText(codProd);
            txtnombProducto.setText(nombProd);
            txtprecioProducto.setText(precProd);
            txtdesProducto.setText(desProd);
            txtcodProveedor.setText(codProv);
            txtcantProducto.setText(cantProd);

            modeloTabla.removeRow(tablaDatos.getSelectedRow());

            txtcodProducto.setEditable(true);
            txtnombProducto.setEditable(true);
            txtprecioProducto.setEditable(true);
            txtdesProducto.setEditable(true);
            txtcodProveedor.setEditable(true);
            txtcantProducto.setEditable(true);

            btnNuevoRegistro.setVisible(false);
            btnEliminarRegistro.setVisible(false);
            btnEditarRegistro.setVisible(false);

            btnGuardar.setVisible(true);
            btnExpt.setVisible(true);
            btnSalir.setVisible(true);

        } else {

            JOptionPane.showMessageDialog(null, "FAVOR SELECCIONAR EL REGISTRO A MODIFICAR");

        }

    }

    // METODO BTNGUARDAR
    public void btnGuardarMetodo() {

        if (validarNoVacio()) {

            if (validarNumeros()) {

                if (validarLetras(txtnombProducto.getText())) {
                    this.guardarDatosTabla();
                    this.limpiarPantalla();

                    try {
                        this.eliminarFichero();
                        this.exportarFichero();
                        JOptionPane.showMessageDialog(null, "Datos exportados al fichero correctamente");
                        this.retornarValoresDefecto();
                    } catch (IOException ex) {
                        Logger.getLogger(panelProductos.class.getName()).log(Level.SEVERE, null, ex);
                    }

                    modeloTabla.setRowCount(0);
                    this.datosTabla();

                } else {
                    JOptionPane.showMessageDialog(null, "FAVOR LLENAR TODOS LOS CAMPOS CORRECTAMENTE");
                }

            } else {
                JOptionPane.showMessageDialog(null, "FAVOR LLENAR TODOS LOS CAMPOS CORRECTAMENTE");
            }
        } else {

            JOptionPane.showMessageDialog(null, "FAVOR LLENAR TODOS LOS CAMPOS CORRECTAMENTE");
        }

    }

    //LISTENERS
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnSalir) {

            if (this.validarNoVacio()) {

                if (this.avanzarOcancelar()) {

                    this.retornarValoresDefecto();
                    modeloTabla.setRowCount(0);
                    this.datosTabla();

                }

            } else {

                this.retornarValoresDefecto();
                modeloTabla.setRowCount(0);
                this.datosTabla();

            }

        }
        if (e.getSource() == btnGuardar) {

            this.btnGuardarMetodo();

        }
        if (e.getSource() == btnExpt) {

        }
        if (e.getSource() == btnNuevoRegistro) {

            try {
                this.nuevoRegistro();
            } catch (IOException ex) {
            }

        }

        if (e.getSource() == btnEditarRegistro) {

            try {
                this.editarRegistro();
            } catch (IOException ex) {
            }

        }

        if (e.getSource() == btnEliminarRegistro) {

            try {
                this.eliminarRegistro();
            } catch (IOException ex) {
            }

        }
    }

}
