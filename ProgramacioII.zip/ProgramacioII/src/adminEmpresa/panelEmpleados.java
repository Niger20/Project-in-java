package adminEmpresa;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

public class panelEmpleados extends JPanel implements ActionListener {

    JLabel lblNomb, lblEdad, lblSal;
    JTextField txtNomb, txtEdad, txtSal;
    JComboBox cargos;
    JButton btnExpt, btnSalir, btnGuardar, btnMostrar, btnNuevoRegistro, btnEditarRegistro, btnEliminarRegistro;
    JTable tablaDatos;
    DefaultTableModel modeloTabla;
    JScrollPane panelTabla;
    Color colorPanel = new Color(131, 156, 181);
    Color colorTxtBox = new Color(224, 224, 224);
    Color colorBtn = new Color(104, 100, 102);
    Color colorBtnCancel = new Color(146, 12, 12);
    String nombre, salario, edad, puesto;

    public panelEmpleados() {

        this.setLayout(null);
        this.setSize(600, 600);
        this.setBackground(colorPanel);
        this.setBorder(new TitledBorder(new EtchedBorder(), "Datos Empleado"));

        botones();
        comboBox();
        labels();
        txtBox();
        tablaDatos();
        datosTabla();

    }

    // METODO DE CONFIGURACION Y ANADIDO DE BOTONES DEL PANEL
    public void botones() {

        //AÑADIR BOTONES
        btnExpt = new JButton("Exportar");
        btnExpt.addActionListener(this);
        btnExpt.setBounds(95, 350, 100, 30);
        btnExpt.setBackground(colorBtn);
        btnExpt.setForeground(Color.WHITE);
        btnExpt.setVisible(false);
        //this.add(btnExpt);

        btnSalir = new JButton("Cancelar");
        btnSalir.addActionListener(this);
        btnSalir.setBounds(265, 350, 150, 30);
        btnSalir.setBackground(colorBtnCancel);
        btnSalir.setForeground(Color.WHITE);
        btnSalir.setVisible(false);
        this.add(btnSalir);

        btnGuardar = new JButton("Guardar");
        btnGuardar.addActionListener(this);
        btnGuardar.setBounds(95, 350, 150, 30);
        btnGuardar.setBackground(colorBtn);
        btnGuardar.setForeground(Color.WHITE);
        btnGuardar.setVisible(false);
        this.add(btnGuardar);

        btnEditarRegistro = new JButton("Editar Registro");
        btnEditarRegistro.addActionListener(this);
        btnEditarRegistro.setBounds(180, 350, 140, 30);
        btnEditarRegistro.setBackground(colorBtn);
        btnEditarRegistro.setForeground(Color.WHITE);
        this.add(btnEditarRegistro);

        btnNuevoRegistro = new JButton("Nuevo Registro");
        btnNuevoRegistro.addActionListener(this);
        btnNuevoRegistro.setBounds(30, 350, 140, 30);
        btnNuevoRegistro.setBackground(colorBtn);
        btnNuevoRegistro.setForeground(Color.WHITE);
        this.add(btnNuevoRegistro);

        btnEliminarRegistro = new JButton("Eliminar Registro");
        btnEliminarRegistro.addActionListener(this);
        btnEliminarRegistro.setBounds(330, 350, 140, 30);
        btnEliminarRegistro.setBackground(colorBtnCancel);
        btnEliminarRegistro.setForeground(Color.WHITE);
        this.add(btnEliminarRegistro);

    }

    // METODO DE CONFIGURACION Y ANADIDO DE COMBO DEL PANEL
    public void comboBox() {

        //COMBO BOX
        cargos = new JComboBox();
        cargos.addItem("");
        cargos.addItem("Gerente");
        cargos.addItem("Contador");
        cargos.addItem("Vigilante");
        cargos.addItem("Auditor");
        cargos.addItem("Señora de limpieza");
        cargos.setBounds(70, 280, 125, 30);
        cargos.setEnabled(false);
        this.add(cargos);

    }

    // METODO DE CONFIGURACION Y ANADIDO DE LABELS DEL PANEL
    public void labels() {

        //CAMPO SALARIO
        lblSal = new JLabel("Salario: ");
        lblSal.setBounds(70, 200, 80, 30);
        lblSal.setForeground(Color.white);
        this.add(lblSal);

        //CAMPO EDAD
        lblEdad = new JLabel("Edad: ");
        lblEdad.setBounds(70, 125, 80, 30);
        lblEdad.setForeground(Color.white);
        this.add(lblEdad);

        lblNomb = new JLabel("Nombre: ");
        lblNomb.setBounds(70, 50, 80, 30);
        lblNomb.setForeground(Color.white);
        this.add(lblNomb);

    }

    // METODO DE CONFIGURACION Y ANADIDO DE TXTFIELD DEL PANEL
    public void txtBox() {

        //CAMPO NOMBRE
        txtNomb = new JTextField();
        txtNomb.setBounds(180, 50, 200, 55);
        //txtNomb.addFocusListener(new validacionDa());
        txtNomb.setEditable(false);
        txtNomb.setBackground(colorTxtBox);
        this.add(txtNomb);

        txtEdad = new JTextField();
        txtEdad.setBounds(180, 125, 200, 55);
        //txtEdad.addFocusListener(new validacionDa());
        txtEdad.setEditable(false);
        txtEdad.setBackground(colorTxtBox);
        this.add(txtEdad);

        txtSal = new JTextField();
        txtSal.setBounds(180, 200, 200, 55);
        //txtSal.addFocusListener(new validacionDa());
        txtSal.setEditable(false);
        txtSal.setBackground(colorTxtBox);
        this.add(txtSal);

    }

    // METODO DE CONFIGURACION Y ANADIDO DE TABLA DEL PANEL
    public void tablaDatos() {

        modeloTabla = new DefaultTableModel() {

            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        modeloTabla.addColumn("Nombre");
        modeloTabla.addColumn("Edad");
        modeloTabla.addColumn("Salario");
        modeloTabla.addColumn("Puesto");

        tablaDatos = new JTable(modeloTabla);
        tablaDatos.setGridColor(Color.black);
        tablaDatos.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tablaDatos.setBackground(colorTxtBox);
        panelTabla = new JScrollPane(tablaDatos);
        panelTabla.setBounds(500, 50, 500, 350);

        this.add(panelTabla);

    }

    //METODO PARA LIMPIAR PANTALLA
    public void limpiarPantalla() {
        txtNomb.setText("");
        txtEdad.setText("");
        txtSal.setText("");
        cargos.setSelectedItem(" ");

    }

    // METODO QUE MODIFICA LA INTERFAZ AL PRESIONAR EL BOTON NUEVO REGISTRO
    public void nuevoRegistro() throws IOException {

        txtSal.setEditable(true);
        txtNomb.setEditable(true);
        txtEdad.setEditable(true);
        btnNuevoRegistro.setVisible(false);
        btnEliminarRegistro.setVisible(false);
        btnEditarRegistro.setVisible(false);
        btnGuardar.setVisible(true);
        btnExpt.setVisible(true);
        btnSalir.setVisible(true);
        cargos.setEnabled(true);

    }

    // METODO PARA ELIMINAR UN REGISTRO
    public void eliminarRegistro() throws IOException {

        if (tablaDatos.getSelectedRow() != -1) {

            modeloTabla.removeRow(tablaDatos.getSelectedRow());

            this.eliminarFichero();
            this.exportarFichero();

            JOptionPane.showMessageDialog(null, "REGISTRO ELIMINADO CORRECTAMENTE");

        } else {

            JOptionPane.showMessageDialog(null, "FAVOR SELECCIONAR EL REGISTRO A ELIMINAR");

        }

    }

    // METODO PARA MODIFICAR UN REGISTRO
    public void editarRegistro() throws IOException {

        if (tablaDatos.getSelectedRow() != -1) {

            String nombre, edad, salario, puesto;
            nombre = "" + tablaDatos.getValueAt(tablaDatos.getSelectedRow(), 0);
            edad = "" + tablaDatos.getValueAt(tablaDatos.getSelectedRow(), 1);
            salario = "" + tablaDatos.getValueAt(tablaDatos.getSelectedRow(), 2);
            puesto = "" + tablaDatos.getValueAt(tablaDatos.getSelectedRow(), 3);

            txtNomb.setText(nombre);
            txtEdad.setText(edad);
            txtSal.setText(salario);
            cargos.setSelectedItem(puesto);

            modeloTabla.removeRow(tablaDatos.getSelectedRow());

            txtSal.setEditable(true);
            txtNomb.setEditable(true);
            txtEdad.setEditable(true);
            btnNuevoRegistro.setVisible(false);
            btnEliminarRegistro.setVisible(false);
            btnEditarRegistro.setVisible(false);
            btnGuardar.setVisible(true);
            btnExpt.setVisible(true);
            btnSalir.setVisible(true);
            cargos.setEnabled(true);

        } else {

            JOptionPane.showMessageDialog(null, "FAVOR SELECCIONAR EL REGISTRO A MODIFICAR");

        }

    }

    // METODO QUE RETORNA LA INTERFAZ A SU ESTADO INICIAL
    public void retornarValoresDefecto() {

        txtEdad.setText("");
        txtEdad.setEditable(false);
        txtNomb.setText("");
        txtNomb.setEditable(false);
        txtSal.setText("");
        txtSal.setEditable(false);
        btnNuevoRegistro.setVisible(true);
        btnEliminarRegistro.setVisible(true);
        btnEditarRegistro.setVisible(true);
        btnGuardar.setVisible(false);
        btnExpt.setVisible(false);
        btnSalir.setVisible(false);
        cargos.setEnabled(false);

    }

    //METODO QUE GUARDA LOS DATOS EN LA TABLA
    public void guardarDatosTabla() {

        nombre = txtNomb.getText();
        salario = txtSal.getText();
        edad = txtEdad.getText();
        puesto = cargos.getSelectedItem().toString();

        String[] datosEmpleado = new String[4];
        datosEmpleado[0] = nombre;
        datosEmpleado[1] = edad;
        datosEmpleado[2] = salario;
        datosEmpleado[3] = puesto;

        modeloTabla.addRow(datosEmpleado);

    }

    // METODO QUE EXPORTA LOS DATOS INGRESADOS AL FICHERO PRODUCTOS
    public void exportarFichero() throws IOException {

        File empleados = new File("empleados.txt");
        FileWriter fw = new FileWriter(empleados, true);
        BufferedWriter bw = new BufferedWriter(fw);
        String cadena = "";

        try {

            for (int fila = 0; fila < modeloTabla.getRowCount(); fila++) {
                for (int columna = 0; columna < modeloTabla.getColumnCount(); columna++) {

                    cadena = cadena + modeloTabla.getValueAt(fila, columna) + ",";
                }
                cadena = cadena + "\n";

            }
            bw.write(cadena);
            bw.close();
            fw.close();

        } catch (Exception e) {
        }

    }

    // METODO PARA BORRAR FICHERO PARA ACTUALIZAR DATOS
    public void eliminarFichero() throws IOException {

        File archivo = new File("empleados.txt");
        if (archivo.delete()) {
            System.out.println("");
        } else {
            System.out.println("");
        }

    }

    // METODO QUE SE ENCARGA DE IMPORTAR DATOS DEL FICHERO A LA TABLA
    public void datosTabla() {

        try {
            File prod = new File("empleados.txt");
            FileReader fr = new FileReader(prod);
            BufferedReader br = new BufferedReader(fr);
            String cadena = br.readLine();

            while (cadena != null) {

                String reg[] = cadena.split(",");
                modeloTabla.addRow(reg);
                cadena = br.readLine();

            }
            br.close();
            fr.close();

        } catch (IOException e) {

        }

    }

    // METODO PARA VALIDAR QUE NINGUN CAMPO ESTE VACIO
    public boolean validarNoVacio() {
        if (!txtNomb.getText().isEmpty() && !txtEdad.getText().isEmpty() && !txtSal.getText().isEmpty() && !"".equals(cargos.getSelectedItem().toString())) {
            return true;
        } else {
            return false;
        }

    }

    //METODO PARA VALIDAR QUE EDAD Y SALARIO SOLO CONTENGAN NUMEROS
    public boolean validarNumeros() {

        try {
            int edad = Integer.parseInt(txtEdad.getText());
            double salario = Double.parseDouble(txtSal.getText());
            return true;
        } catch (Exception e) {
            return false;
        }

    }

    // METODO PARA VALIDAR QUE NOMBRE UNICAMENTE CONTENGA LETRAS
    public boolean validarLetras(String cadena) {

        for (int i = 0; i < cadena.length(); i++) {

            char caracter = cadena.toUpperCase().charAt(i);
            int valorASCII = (int) caracter;

            if (valorASCII != 165 && (valorASCII < 65 || valorASCII > 90) && valorASCII != 32) {
                return false;
            }

        }
        return true;

    }

    public boolean avanzarOcancelar() {
        int opcion = JOptionPane.showConfirmDialog(null, "¿Estás seguro, los datos que no se hayan exportado se eliminaran?", "Confirmación", JOptionPane.OK_CANCEL_OPTION);
        if (opcion == JOptionPane.OK_OPTION) {
            return true;
        } else {
            return false;
        }
    }

    // METODO BTNGUARDAR
    public void btnGuardarMetodo() {

        if (validarNoVacio()) {

            if (validarNumeros()) {

                if (validarLetras(txtNomb.getText())) {
                    this.guardarDatosTabla();
                    this.limpiarPantalla();

                    try {
                        this.eliminarFichero();
                        this.exportarFichero();
                        JOptionPane.showMessageDialog(null, "Datos exportados al fichero correctamente");
                        this.retornarValoresDefecto();
                    } catch (IOException ex) {
                        Logger.getLogger(panelProductos.class.getName()).log(Level.SEVERE, null, ex);
                    }

                    modeloTabla.setRowCount(0);
                    this.datosTabla();

                } else {
                    JOptionPane.showMessageDialog(null, "FAVOR LLENAR TODOS LOS CAMPOS CORRECTAMENTE");
                }

            } else {
                JOptionPane.showMessageDialog(null, "FAVOR LLENAR TODOS LOS CAMPOS CORRECTAMENTE");
            }
        } else {

            JOptionPane.showMessageDialog(null, "FAVOR LLENAR TODOS LOS CAMPOS CORRECTAMENTE");
        }

    }

    //CONFIG DE ACTION LISTENER
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnSalir) {
            if (this.validarNoVacio()) {

                if (this.avanzarOcancelar()) {

                    this.retornarValoresDefecto();
                    modeloTabla.setRowCount(0);
                    this.datosTabla();

                }
            }
        }
        if (e.getSource() == btnGuardar) {

           this.btnGuardarMetodo();
           
        }

        if (e.getSource() == btnExpt) {

        }
        if (e.getSource() == btnNuevoRegistro) {

            try {
                this.nuevoRegistro();
            } catch (IOException ex) {
                Logger.getLogger(panelEmpleados.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

        if (e.getSource() == btnEditarRegistro) {

            try {
                this.editarRegistro();
            } catch (IOException ex) {
                Logger.getLogger(panelEmpleados.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

        if (e.getSource() == btnEliminarRegistro) {

            try {
                this.eliminarRegistro();
            } catch (IOException ex) {
                Logger.getLogger(panelEmpleados.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

    }

}

