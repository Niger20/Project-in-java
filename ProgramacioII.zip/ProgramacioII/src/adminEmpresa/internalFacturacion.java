package adminEmpresa;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class internalFacturacion extends JInternalFrame implements ActionListener {

    int R, G, B;
    Color colorPanelmod;
    JButton btnCambiarcolor;
    JLabel codColor;
    DefaultTableModel modeloTabla;
    JTable tablaDatos;
    Color colorPanel = new Color(139, 178, 201);
    Color colorTxtBox = new Color(224, 224, 224);
    Color colorBtn = new Color(104, 100, 102);
    JScrollPane panelTabla;
    JLabel nombreCliente, rucCliente, cantProductos, numeroFact, fechaFact, totalProd, IVAprod;
    JTextField nombreClientetxt, rucClientetxt, cantidadProductos;
    JComboBox productosFac;
    panelFactProd pan = new panelFactProd();
    panelFactCliente pan2 = new panelFactCliente();
    panelFactFactura pan3 = new panelFactFactura();

    public internalFacturacion() throws IOException {

        this.setLayout(null);
        this.setTitle("FACTURACIÓN");
        this.setResizable(false);
        this.setClosable(true);
        this.setBounds(0, 0, 1000, 400);
        this.setDefaultCloseOperation(HIDE_ON_CLOSE);

        btnCambiarcolor = new JButton("CAMBIAR COLOR");
        btnCambiarcolor.setForeground(Color.white);
        btnCambiarcolor.setBorder(null);
        btnCambiarcolor.setBounds(50, 50, 100, 50);
        btnCambiarcolor.addActionListener(this);
        //this.add(btnCambiarcolor);
        codColor = new JLabel();
        //this.add(codColor);
        this.setBackground(colorPanel);

        this.add(pan);
        this.add(pan2);
        this.add(pan3);
        //tablaDatos();

    }

    public void tablaDatos() {

        modeloTabla = new DefaultTableModel() {

            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        modeloTabla.addColumn("Cod prodcuto");
        modeloTabla.addColumn("Nomb producto");
        modeloTabla.addColumn("Precio producto");
        modeloTabla.addColumn("Cant producto");
        modeloTabla.addColumn("TOTAL");

        tablaDatos = new JTable(modeloTabla);
        tablaDatos.setGridColor(Color.black);
        tablaDatos.setBackground(colorTxtBox);
        panelTabla = new JScrollPane(tablaDatos);
        panelTabla.setBounds(50, 50, 500, 300);

        this.add(panelTabla);

    }

    public void randomnumeros() throws InterruptedException {

        R = (int) (Math.floor(Math.random() * (255 - 0 + 1) + 0));
        G = (int) (Math.floor(Math.random() * (255 - 0 + 1) + 0));
        B = (int) (Math.floor(Math.random() * (255 - 0 + 1) + 0));

        colorPanelmod = new Color(R, G, B);

        String rojo = R + "";
        String verde = G + "";
        String azul = B + "";

        btnCambiarcolor.setBackground(colorPanelmod);
        this.setBackground(colorPanelmod);

        codColor.setText("R: " + rojo + " G: " + verde + " B: " + azul);
        codColor.setForeground(Color.white);
        codColor.setBounds(100, 100, 250, 20);

    }
    
    public void actualizarDatosCombo(){
        
        pan.actualizarDatosCombo();
        
    }

    public void labels() {
        nombreCliente = new JLabel("Nombre");
        rucCliente = new JLabel("RUC");
        cantProductos = new JLabel("cantidad");
        numeroFact = new JLabel();
        totalProd = new JLabel();
        IVAprod = new JLabel();

        // CREAR LABEL CON LA FECHA ACTUAL
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date fechaActual = new Date();
        String Fecha = dateFormat.format(fechaActual);

        fechaFact = new JLabel(Fecha);
        fechaFact.setForeground(Color.black);
        fechaFact.setBounds(1125, 10, 150, 30);

    }

    public void txtBoxs() {
        nombreClientetxt = new JTextField();
        rucClientetxt = new JTextField();
        cantidadProductos = new JTextField();

    }

    public void comboBox() {

        productosFac = new JComboBox();

    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnCambiarcolor) {
            try {
                randomnumeros();
            } catch (InterruptedException ex) {
                Logger.getLogger(internalFacturacion.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

}
