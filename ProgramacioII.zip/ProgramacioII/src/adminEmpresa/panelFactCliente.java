package adminEmpresa;

import PracticasAWT.Paneldatos;
import java.awt.Color;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

public class panelFactCliente extends JPanel implements KeyListener {

    Color colorPanel = new Color(139, 178, 201);
    JLabel nombreClient, rucClient, telClient;
    JTextField nombreCliente, rucCliente, telCliente;
    String nombre, ruc, telefono;

    public panelFactCliente() {

        this.setLayout(null);
        this.setBackground(colorPanel);
        this.setBounds(50, 0, 300, 175);
        this.setBorder(new TitledBorder(new EtchedBorder(), "Datos Cliente"));

        labels();
        txtbox();
    }

    public void labels() {

        nombreClient = new JLabel("Nombre:");
        rucClient = new JLabel("RUC:");
        telClient = new JLabel("Telefono:");

        nombreClient.setBounds(50, 20, 70, 20);
        rucClient.setBounds(50, 60, 70, 20);
        telClient.setBounds(50, 100, 70, 20);

        this.add(nombreClient);
        this.add(rucClient);
        this.add(telClient);

    }

    public void txtbox() {

        nombreCliente = new JTextField();
        nombreCliente.addFocusListener(new obtDatos());
        rucCliente = new JTextField();
        rucCliente.addFocusListener(new obtDatos());
        telCliente = new JTextField();
        telCliente.addFocusListener(new obtDatos());

        nombreCliente.setBounds(120, 20, 100, 20);
        nombreCliente.addKeyListener(this);

        rucCliente.setBounds(120, 60, 100, 20);

        telCliente.setBounds(120, 100, 100, 20);
        telCliente.addKeyListener(this);

        this.add(nombreCliente);
        this.add(rucCliente);
        this.add(telCliente);

    }

    public void limpiarPantalla() {

        nombreCliente.setText("");
        rucCliente.setText("");
        telCliente.setText("");

    }

    public void datosFactFichero() throws IOException {

        File datos = new File("datosfact2.txt");
        FileWriter fw = new FileWriter(datos, true);
        BufferedWriter bw = new BufferedWriter(fw);
        String cadena = "";

        try {

            nombre = nombreCliente.getText();
            ruc = rucCliente.getText();
            telefono = telCliente.getText();

            cadena = nombre + " ," + ruc + " ," + telefono + " ,";
            bw.write(cadena);

            bw.close();
            fw.close();

        } catch (Exception e) {
        }

    }

    public void destruirDataFichero() {

        File archivo = new File("datosfact2.txt");
        if (archivo.delete()) {
            System.out.println("");
        } else {
            System.out.println("");
        }

    }

    @Override
    public void keyTyped(KeyEvent e) {

        char karakter = e.getKeyChar();

        if (e.getSource() == telCliente) {

            if (!(((karakter >= '0') && (karakter <= '9') || (karakter == KeyEvent.VK_BACK_SPACE) || (karakter == KeyEvent.VK_DELETE)))) {
                getToolkit().beep();
                e.consume();
            }

            if (karakter == KeyEvent.VK_BACK_SPACE) { // Si la tecla presionada es "backspace"
                String text = telCliente.getText();
                if (text.length() > 0) { // Si hay texto en el campo de texto
                    telCliente.setText(text.substring(0, text.length())); // Eliminar el último carácter
                }
            }

        }

        if (e.getSource() == nombreCliente) {

            if (!Character.isLetter(karakter) && !Character.isWhitespace(karakter)) { // Si la tecla presionada no es una letra
                e.consume(); // Ignorar la tecla presionada
            }

            if (karakter == KeyEvent.VK_BACK_SPACE) { // Si la tecla presionada es "backspace"
                String text = nombreCliente.getText();
                if (text.length() > 0) { // Si hay texto en el campo de texto
                    nombreCliente.setText(text.substring(0, text.length())); // Eliminar el último carácter
                }
            }

        }

    }

    @Override
    public void keyPressed(KeyEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void keyReleased(KeyEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public class obtDatos extends FocusAdapter {

        @Override
        public void focusLost(FocusEvent f) {

            if (f.getSource() == nombreCliente) {

                destruirDataFichero();
                try {
                    datosFactFichero();
                } catch (IOException ex) {
                    Logger.getLogger(panelFactCliente.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
            if (f.getSource() == rucCliente) {

                destruirDataFichero();
                try {
                    datosFactFichero();
                } catch (IOException ex) {
                    Logger.getLogger(panelFactCliente.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
            if (f.getSource() == telCliente) {

                destruirDataFichero();
                try {
                    datosFactFichero();
                } catch (IOException ex) {
                    Logger.getLogger(panelFactCliente.class.getName()).log(Level.SEVERE, null, ex);
                }

            }

        }

    }

}
