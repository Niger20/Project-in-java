package adminEmpresa;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JToolBar;
import javax.swing.border.EtchedBorder;

public class interfaz extends JFrame implements ActionListener, Runnable {

    panelEmpleados pan;
    JToolBar barraHe, barraTareas;
    JButton btnGuardarBarra, btnSalirBarra, btnEditBarra;
    JMenuBar barraMenu;
    JMenu mnuFile, mnuTools, mnuProcess;
    JMenuItem FileSalir, FileGuardar, FileEditar, ProcessFacturar, toolsPlanilla, toolsInventario;
    JLabel fechaBarraT;
    JTabbedPane tabPanel;
    JDesktopPane desk;
    internalFacturacion fact;
    internalPlanilla plani;
    internalInventario invent;
    String cadena;
    String[] regGlob = new String[10000];
    SimpleDateFormat dateFormat;
    Date fechaActual;
    String Fecha;
    panelEmpleados panE = new panelEmpleados();
    panelProductos panP = new panelProductos();

    public interfaz() {
        Color colorFrame = new Color(41, 82, 100);

        this.setLayout(null);
        this.setTitle("Mi primera ventana");
        this.setExtendedState(MAXIMIZED_BOTH);
        this.setUndecorated(true);

        //SET CONTENT PANE A DESK
        desk = new JDesktopPane();
        this.setContentPane(desk);
        desk.setBackground(colorFrame);

        menu();
        toolBar();
        barraTareas();
        try {
            jinternalFrame();
        } catch (IOException ex) {
            Logger.getLogger(interfaz.class.getName()).log(Level.SEVERE, null, ex);
        }
        tabPanel();

    }

    public String[] getRegGlob() {
        return regGlob;
    }

    public void tabPanel() {

        tabPanel = new JTabbedPane();
        //tabPanel.setLayout(null);
        tabPanel.addTab("Empleados", panE);
        tabPanel.addTab("Productos", panP);
        tabPanel.setBounds(100, 80, 1100, 500);

        desk.add(tabPanel);

    }

    public void jinternalFrame() throws IOException {

        fact = new internalFacturacion();
        plani = new internalPlanilla();
        invent = new internalInventario();

        desk.add(fact);
        fact.setVisible(false);

        desk.add(plani);
        plani.setVisible(false);
        
        desk.add(invent);
        invent.setVisible(false);


    }

    public void toolBar() {

        // COLORES PARA ELEMETOS
        Color colorBarra = new Color(200, 200, 200);

        //ICONOS PARA LOS BOTONES
        Image iconobtnSalir = new ImageIcon("src/Iconos/Salir.png").getImage();
        ImageIcon iconobtnSalirEsc = new ImageIcon(iconobtnSalir.getScaledInstance(30, 30, Image.SCALE_SMOOTH));
        Image iconobtnGuardar = new ImageIcon("src/Iconos/Guardar.png").getImage();
        ImageIcon iconobtnGuardarEsc = new ImageIcon(iconobtnGuardar.getScaledInstance(30, 30, Image.SCALE_SMOOTH));
        Image iconobtnEditar = new ImageIcon("src/Iconos/Editar.png").getImage();
        ImageIcon iconobtnEditarEsc = new ImageIcon(iconobtnEditar.getScaledInstance(30, 30, Image.SCALE_SMOOTH));

        //CONFIG TOOLBAR
        barraHe = new JToolBar();
        barraHe.setBounds(0, 0, 2000, 40);
        barraHe.setBorder(new EtchedBorder());
        barraHe.setBackground(colorBarra);
        barraHe.setFloatable(false);

        //AÑADIR BOTONES A LA TOOLBAR
        btnSalirBarra = new JButton();
        btnSalirBarra.setIcon(iconobtnSalirEsc);
        btnSalirBarra.setBackground(colorBarra);
        btnSalirBarra.setBorder(null);
        btnSalirBarra.addActionListener(this);
        barraHe.add(btnSalirBarra);
        barraHe.addSeparator();

        btnGuardarBarra = new JButton();
        btnGuardarBarra.setIcon(iconobtnGuardarEsc);
        btnGuardarBarra.setBackground(colorBarra);
        btnGuardarBarra.setBorder(null);
        btnGuardarBarra.addActionListener(this);
        barraHe.add(btnGuardarBarra);
        barraHe.addSeparator();

        btnEditBarra = new JButton();
        btnEditBarra.setIcon(iconobtnEditarEsc);
        btnEditBarra.setBackground(colorBarra);
        btnEditBarra.setBorder(null);
        btnEditBarra.addActionListener(this);
        barraHe.add(btnEditBarra);
        barraHe.addSeparator();

        desk.add(barraHe);

    }

    public void menu() {
        // COLORES PARA ELEMETOS
        Color colorBarraM = new Color(150, 150, 150);

        //CONFIG MENU BAR
        barraMenu = new JMenuBar();
        barraMenu.setBackground(colorBarraM);
        barraMenu.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));

        //CONFIG MNU
        mnuFile = new JMenu("File");
        mnuTools = new JMenu("Tools");
        mnuProcess = new JMenu("Process");

        barraMenu.add(mnuFile);
        barraMenu.add(mnuTools);
        barraMenu.add(mnuProcess);

        //CONFIG MNUITEM PARA FILE
        FileSalir = new JMenuItem("Salir");
        FileSalir.addActionListener(this);
        FileGuardar = new JMenuItem("Guardar");
        FileGuardar.addActionListener(this);
        FileEditar = new JMenuItem("Editar");
        FileEditar.addActionListener(this);

        //CONFIG MNU ITEN PROCESS
        ProcessFacturar = new JMenuItem("Facturar");
        ProcessFacturar.addActionListener(this);
        mnuProcess.add(ProcessFacturar);

        //toolsPlanilla
        toolsPlanilla = new JMenuItem("Planilla");
        toolsPlanilla.addActionListener(this);
        toolsInventario = new JMenuItem("Inventario");
        toolsInventario.addActionListener(this);
        mnuTools.add(toolsPlanilla);
        mnuTools.addSeparator();
        mnuTools.add(toolsInventario);

        
        
        mnuFile.add(FileSalir);
        mnuFile.addSeparator();
        mnuFile.add(FileGuardar);
        mnuFile.addSeparator();
        mnuFile.add(FileEditar);

        this.setJMenuBar(barraMenu);

    }

    public void barraTareas() {

        //CONFIGURAR BARRA TAREAS
        barraTareas = new JToolBar();
        barraTareas.setBounds(0, 658, 1300, 40);
        barraTareas.setBackground(Color.white);
        barraTareas.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        barraTareas.setFloatable(false);
        barraTareas.setLayout(null);

        // CREAR LABEL CON LA FECHA ACTUAL
        fechaBarraT = new JLabel();
        fechaBarraT.setForeground(Color.black);
        fechaBarraT.setBounds(1125, 10, 150, 30);

        // ADD ELEMENTS
        barraTareas.add(fechaBarraT);
        desk.add(barraTareas);

    }

    @Override
    public void run() {
        int i = 0;

        while (i == 0) {

            dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
            fechaActual = new Date();
            Fecha = dateFormat.format(fechaActual);
            fechaBarraT.setText(Fecha);

            try {
                Thread.sleep(1000);
            } catch (InterruptedException ex) {
                Logger.getLogger(interfaz.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

    }

    public class cerrarVentana extends WindowAdapter {

        @Override
        public void windowClosing(WindowEvent ev) {
            System.exit(0);
        }
    }

    public void importarLista_De_Productos() {

        try {
            File prod = new File("productos.txt");
            FileReader fr = new FileReader(prod);
            BufferedReader br = new BufferedReader(fr);
            String cadena = br.readLine();
            int i = 0;
            while (cadena != null) {

                String reg[] = cadena.split(",");
                regGlob[i] = reg[1];
                cadena = br.readLine();
                i++;

            }
            br.close();
            fr.close();

        } catch (IOException e) {

        }

    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnSalirBarra) {
            System.exit(0);
        }
        if (e.getSource() == btnGuardarBarra) {
            
            int panelSeleccionado = tabPanel.getSelectedIndex();
            if (panelSeleccionado == 0) {

                panE.btnGuardarMetodo();
            } else {

                panP.btnGuardarMetodo();

            }
        }
        if (e.getSource() == btnEditBarra) {
            
            int panelSeleccionado = tabPanel.getSelectedIndex();
            if (panelSeleccionado == 0) {

                try {
                    panE.editarRegistro();
                } catch (IOException ex) {
                    Logger.getLogger(interfaz.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {

                try {
                    panP.editarRegistro();
                } catch (IOException ex) {
                    Logger.getLogger(interfaz.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            
        }
        if (e.getSource() == ProcessFacturar) {

            fact.setVisible(true);
            fact.actualizarDatosCombo();

        }
        if (e.getSource() == FileSalir) {
            System.exit(0);

        }
        if (e.getSource() == FileEditar) {

            int panelSeleccionado = tabPanel.getSelectedIndex();
            if (panelSeleccionado == 0) {

                try {
                    panE.editarRegistro();
                } catch (IOException ex) {
                    Logger.getLogger(interfaz.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {

                try {
                    panP.editarRegistro();
                } catch (IOException ex) {
                    Logger.getLogger(interfaz.class.getName()).log(Level.SEVERE, null, ex);
                }

            }

        }
        if (e.getSource() == FileGuardar) {

            int panelSeleccionado = tabPanel.getSelectedIndex();
            if (panelSeleccionado == 0) {

                panE.btnGuardarMetodo();
            } else {

                panP.btnGuardarMetodo();

            }

        }
        if (e.getSource() == toolsPlanilla) {

            plani.setVisible(true);
            plani.datosTabla();

        }
        
        if (e.getSource() == toolsInventario) {

            invent.setVisible(true);
            invent.datosTabla();
            invent.actualizarDatosTabla();
        }

    }

}
