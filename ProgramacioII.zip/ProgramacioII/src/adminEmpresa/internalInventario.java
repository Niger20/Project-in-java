/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package adminEmpresa;

import java.awt.Color;
import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import static javax.swing.WindowConstants.HIDE_ON_CLOSE;
import javax.swing.table.DefaultTableModel;

public class internalInventario extends JInternalFrame implements ActionListener{

    Color colorPanel = new Color(139, 178, 201);
    Color colorTxtBox = new Color(224, 224, 224);
    Color colorBtn = new Color(104, 100, 102);
    DefaultTableModel modeloTabla;
    JTable tablaDatos;
    JScrollPane panelTabla;
    JButton btnMostrarFich;

    public internalInventario() {

        this.setLayout(null);
        this.setTitle("INVENTARIO");
        this.setResizable(false);
        this.setClosable(true);
        this.setBounds(0, 0, 1000, 500);
        this.setDefaultCloseOperation(HIDE_ON_CLOSE);
        this.setBackground(colorPanel);

        this.tablaDatos();
        this.datosTabla();
        this.actualizarDatosTabla();
        this.botones();

    }
    
    public void botones(){
        
        btnMostrarFich = new JButton("MOSTRAR FICHERO DE INVENTARIO");
        btnMostrarFich.setBounds(300, 400, 400, 50);
        btnMostrarFich.addActionListener(this);
        btnMostrarFich.setBackground(colorBtn);
        btnMostrarFich.setForeground(Color.white);
        this.add(btnMostrarFich);
        
    }

    // IMPORTAR DESDE EL FICHERO LOS DATOS DE LA TABLA
    public void datosTabla() {

        modeloTabla.setRowCount(0);

        try {
            File prod = new File("productos.txt");
            FileReader fr = new FileReader(prod);
            BufferedReader br = new BufferedReader(fr);
            String cadena = br.readLine();

            while (cadena != null) {

                String reg[] = cadena.split(",");
                modeloTabla.addRow(reg);
                cadena = br.readLine();

            }
            br.close();
            fr.close();

        } catch (IOException e) {

        }
        
         try {
            this.eliminarFichero();
        } catch (IOException ex) {
            Logger.getLogger(internalPlanilla.class.getName()).log(Level.SEVERE, null, ex);
        }

        try {
            this.exportarFichero();
        } catch (IOException ex) {
            Logger.getLogger(internalPlanilla.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void actualizarDatosTabla() {

        try {
            File resumen = new File("RESUMENFACTURAS.txt");
            FileReader fr = new FileReader(resumen);
            BufferedReader br = new BufferedReader(fr);
            String cadena = br.readLine();

            while (cadena != null) {

                String reg[] = cadena.split(",");
                for (int i = 0; i < tablaDatos.getRowCount(); i++) {
                    if (reg[0].equals(tablaDatos.getValueAt(i, 1).toString())) {
                        int cantidadResumen = Integer.parseInt(reg[1]);
                        int cantidadTabla = Integer.parseInt((String) tablaDatos.getValueAt(i, 5));

                        int cantidadNueva = cantidadTabla - cantidadResumen;
                        String strCantidad = "" + cantidadNueva;

                        tablaDatos.setValueAt(strCantidad, i, 5);

                    }
                }
                cadena = br.readLine();

            }
            br.close();
            fr.close();

        } catch (IOException e) {

        }

    }

    public void tablaDatos() {

        modeloTabla = new DefaultTableModel() {

            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        modeloTabla.addColumn("Cod producto");
        modeloTabla.addColumn("Nomb producto");
        modeloTabla.addColumn("Precio producto");
        modeloTabla.addColumn("Des producto");
        modeloTabla.addColumn("Cod proveedor");
        modeloTabla.addColumn("Cant producto");

        tablaDatos = new JTable(modeloTabla);
        tablaDatos.setGridColor(Color.black);
        tablaDatos.setBackground(colorTxtBox);
        tablaDatos.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        panelTabla = new JScrollPane(tablaDatos);
        panelTabla.setBounds(30, 20, 920, 350);

        this.add(panelTabla);

    }

    //METODO PARA EXPORTAR AL FICHERO LOS DATOS DE LA TABLA
    public void exportarFichero() throws IOException {

        File planilla = new File("inventario.txt");
        FileWriter fw = new FileWriter(planilla, true);
        BufferedWriter bw = new BufferedWriter(fw);
        String cadena = "COD PROD|NOMB PROD|PRECIO PROD|DES PROD|COD PROD|CANT PROD|\n";

        try {

            for (int fila = 0; fila < modeloTabla.getRowCount(); fila++) {
                for (int columna = 0; columna < modeloTabla.getColumnCount(); columna++) {

                    cadena = cadena + modeloTabla.getValueAt(fila, columna) + "|";
                }
                cadena = cadena + "\n";

            }
            bw.write(cadena);
            bw.close();
            fw.close();

        } catch (Exception e) {
        }

    }

    // METODO PARA BORRAR FICHERO PARA ACTUALIZAR DATOS
    public void eliminarFichero() throws IOException {

        File archivo = new File("inventario.txt");
        if (archivo.delete()) {
            System.out.print("");
        } else {
            System.out.print("");
        }

    }
    
    public void mostrarFichero(){
        
        try {
            File archivo = new File("inventario.txt");
            
            if (!Desktop.isDesktopSupported()) {
                JOptionPane.showMessageDialog(null, "NO SOPORTA ESTA FUNCION");
            }
            
            Desktop desktop = Desktop.getDesktop();
            if (archivo.exists()) {
                desktop.open(archivo);
            }else{
                JOptionPane.showMessageDialog(null, "NO EXISTE EL FICHERO");
            }
            
        } catch (Exception e) {
        }
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
         if (e.getSource() == btnMostrarFich) {
            this.mostrarFichero();
        }

    }
}

