package adminEmpresa;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

public class panelFactProd extends JPanel implements ActionListener, ItemListener, KeyListener {

    JLabel precioProd, cantProd, productosCombo, subtotalProd, totalProd, IVAprod, prodAnadidos, prodAnadidosnum;
    JTextField precioProdtxt, cantidadProdtxt, totalProdtxt, ivaProdtxt, subtotaltxt;
    JComboBox productosFac;
    JButton btnCalc, btnAddProd;
    Color colorPanel = new Color(139, 178, 201);
    Color colorBtn = new Color(104, 100, 102);
    Font fuente = new Font("Arial", Font.BOLD, 13);
    String product_, cant_, subtot_, IVA_, tot_, contProdAdd, prodAnadidos_;
    int contProdAdd_ = 1;
    int conProdAdd_1;
    boolean error;

    public panelFactProd() {

        this.setLayout(null);
        this.setBackground(colorPanel);
        this.setBounds(50, 175, 900, 175);
        this.setBorder(new TitledBorder(new EtchedBorder(), "Factura"));

        labels();
        txtBoxs();
        comboBox();
        this.actualizarDatosCombo();
        botones();
        actcontProd();

    }

    public void setContProdAdd_(int contProdAdd_) {
        this.contProdAdd_ = contProdAdd_;
    }

    public void labels() {
        precioProd = new JLabel("Precio:");
        cantProd = new JLabel("Cantidad:");
        productosCombo = new JLabel("Productos: ");
        subtotalProd = new JLabel("SUbtotal:");
        totalProd = new JLabel("TOTAL: ");
        IVAprod = new JLabel("IVA: ");
        prodAnadidos = new JLabel("Productos anadidos: ");
        prodAnadidosnum = new JLabel(contProdAdd);

        precioProd.setBounds(50, 50, 70, 20);
        precioProd.setFont(fuente);

        IVAprod.setBounds(250, 50, 70, 20);
        IVAprod.setForeground(Color.red);
        IVAprod.setFont(fuente);

        cantProd.setBounds(50, 90, 70, 20);
        cantProd.setFont(fuente);

        totalProd.setBounds(250, 90, 70, 20);
        totalProd.setFont(fuente);

        subtotalProd.setBounds(50, 130, 70, 20);
        subtotalProd.setFont(fuente);

        productosCombo.setBounds(450, 50, 90, 20);
        productosCombo.setFont(fuente);

        prodAnadidos.setBounds(250, 130, 150, 20);
        prodAnadidos.setFont(fuente);
        prodAnadidos.setVisible(false);

        prodAnadidosnum.setBounds(400, 130, 90, 20);
        prodAnadidosnum.setVisible(false);

        this.add(precioProd);
        this.add(cantProd);
        this.add(productosCombo);
        this.add(subtotalProd);
        this.add(IVAprod);
        this.add(totalProd);
        this.add(prodAnadidos);
        this.add(prodAnadidosnum);

    }

    public void botones() {

        btnCalc = new JButton("Añadir");
        btnCalc.addActionListener(this);
        btnCalc.setBounds(750, 130, 100, 30);
        btnCalc.setBackground(colorBtn);
        btnCalc.setForeground(Color.WHITE);
        btnCalc.setVisible(true);
        this.add(btnCalc);

        btnAddProd = new JButton("Añadir otro producto");
        btnAddProd.addActionListener(this);
        btnAddProd.setBounds(650, 130, 200, 30);
        btnAddProd.setBackground(colorBtn);
        btnAddProd.setForeground(Color.WHITE);
        btnAddProd.setVisible(false);
        this.add(btnAddProd);

    }

    public void calcularTotal() {
        destruirFactFichero();
        try {
            File prod = new File("productos.txt");
            FileReader fr = new FileReader(prod);
            BufferedReader br = new BufferedReader(fr);
            String cadena = br.readLine();

            int precio, cantidad, total, IVA, subtotal;

            String sPrecio, sSubTotal, iSeleccionado, sIVA, sTotal;
            iSeleccionado = productosFac.getSelectedItem().toString();

            if (!"".equals(cantidadProdtxt.getText())) {

                while (cadena != null) {

                    String reg[] = cadena.split(",");
                    if (iSeleccionado.equals(reg[1])) {
                        precio = Integer.parseInt(reg[2]);
                        cantidad = Integer.parseInt(cantidadProdtxt.getText());
                        subtotal = precio * cantidad;
                        IVA = (int) (subtotal * 0.15);
                        total = subtotal + IVA;

                        sPrecio = "" + precio;
                        sSubTotal = "" + subtotal;
                        sIVA = "" + IVA;
                        sTotal = "" + total;

                        precioProdtxt.setText(sPrecio);
                        subtotaltxt.setText(sSubTotal);
                        totalProdtxt.setText(sTotal);
                        ivaProdtxt.setText(sIVA);

                        datosFactFichero();

                    }
                    cadena = br.readLine();

                }

                br.close();
                fr.close();

            } else {
                JOptionPane.showMessageDialog(null, "FAVOR INGRESE LA CANTIDAD DEL PRODUCTO");
            }

        } catch (IOException e) {

        }

    }

    public void datosFactFichero() throws IOException {

        File datos = new File("datosfact.txt");
        FileWriter fw = new FileWriter(datos, true);
        BufferedWriter bw = new BufferedWriter(fw);
        String cadena = "";

        try {

            product_ = productosFac.getSelectedItem().toString();
            cant_ = cantidadProdtxt.getText();
            subtot_ = subtotaltxt.getText();
            IVA_ = ivaProdtxt.getText();
            tot_ = totalProdtxt.getText();
            prodAnadidos_ = prodAnadidosnum.getText();

            cadena = product_ + "," + cant_ + "," + subtot_ + "," + IVA_ + "," + tot_ + "," + prodAnadidos_;
            bw.write(cadena);

            bw.close();
            fw.close();

        } catch (Exception e) {
        }

    }

    public void destruirFactFichero() {

        File archivo = new File("datosfact.txt");
        if (archivo.delete()) {
            System.out.println("");
        } else {
            System.out.println("");
        }

    }

    public void txtBoxs() {
        precioProdtxt = new JTextField();
        cantidadProdtxt = new JTextField();
        subtotaltxt = new JTextField();
        totalProdtxt = new JTextField();
        ivaProdtxt = new JTextField();

        precioProdtxt.setBounds(120, 50, 100, 20);
        precioProdtxt.setEditable(false);

        totalProdtxt.setBounds(320, 90, 100, 20);
        totalProdtxt.setEditable(false);

        ivaProdtxt.setBounds(320, 50, 100, 20);
        ivaProdtxt.setEditable(false);

        cantidadProdtxt.setBounds(120, 90, 100, 20);
        cantidadProdtxt.setText("1");
        cantidadProdtxt.addKeyListener(this);

        subtotaltxt.setBounds(120, 130, 100, 20);
        subtotaltxt.setEditable(false);

        this.add(precioProdtxt);
        this.add(cantidadProdtxt);
        this.add(subtotaltxt);
        this.add(ivaProdtxt);
        this.add(totalProdtxt);

    }

    public void limpiarTxt() {

        precioProdtxt.setText("");
        cantidadProdtxt.setText("");
        subtotaltxt.setText("");
        totalProdtxt.setText("");
        ivaProdtxt.setText("");

    }

    public void comboBox() {

        productosFac = new JComboBox();
        productosFac.setBounds(550, 50, 150, 20);
        productosFac.addItemListener(this);
        this.add(productosFac);

    }

    public void contProdAdded() throws IOException {

        File cont = new File("contDat.txt");
        try {

            FileReader fr = new FileReader(cont);
            BufferedReader br = new BufferedReader(fr);
            String contprd = br.readLine();
            int datoSeleccionar = contprd.length() - 1;
            String contprd_ = "" + contprd.charAt(datoSeleccionar);
            conProdAdd_1 = Integer.parseInt(contprd_);

        } catch (IOException e) {
        }

        contProdAdd_ = conProdAdd_1 + 1;

        FileWriter fw = new FileWriter(cont, true);
        BufferedWriter bw = new BufferedWriter(fw);
        String cadena = "";

        try {

            cadena = "" + contProdAdd_;

            bw.write(cadena);
            bw.close();
            fw.close();

        } catch (Exception e) {
        }

        prodAnadidos.setVisible(true);

    }

    public void exportarFicheroAcum() throws IOException {

        File productos = new File("datosFactAcum.txt");
        FileWriter fw = new FileWriter(productos, true);
        BufferedWriter bw = new BufferedWriter(fw);
        String cadena = "";
        String cadena_ = "";

        try {

            product_ = productosFac.getSelectedItem().toString();
            cant_ = cantidadProdtxt.getText();
            subtot_ = subtotaltxt.getText();
            IVA_ = ivaProdtxt.getText();
            tot_ = totalProdtxt.getText();

            cadena_ = product_ + "," + cant_ + "," + subtot_ + "," + IVA_ + "," + tot_ + ",";
            cadena = cadena_ + "\n";

            bw.write(cadena);
            bw.close();
            fw.close();

        } catch (Exception e) {
        }

    }

    public void deleteFicheroAcum() {

        File archivo = new File("datosFactAcum.txt");
        if (archivo.delete()) {
            System.out.println("");
        } else {
            System.out.println("");
        }

    }

    public void actcontProd() {
        File cont = new File("contDat.txt");
        try {
            FileReader fr = new FileReader(cont);
            BufferedReader br = new BufferedReader(fr);
            String contprd = br.readLine();
            int datoSeleccionar = contprd.length() - 1;
            String contprd_ = "" + contprd.charAt(datoSeleccionar);
            int contprdint = Integer.parseInt(contprd_);
            String contprd_Mostar = "" + contprdint;
            prodAnadidosnum.setText(contprd_Mostar);
        } catch (IOException e) {
        }

    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == btnCalc) {

            this.calcularTotal();
            if (error == false) {
                btnAddProd.setVisible(true);
                btnCalc.setVisible(false);

                try {
                    contProdAdded();
                } catch (IOException ex) {
                    Logger.getLogger(panelFactProd.class.getName()).log(Level.SEVERE, null, ex);
                }

                try {
                    exportarFicheroAcum();
                } catch (IOException ex) {
                    Logger.getLogger(panelFactProd.class.getName()).log(Level.SEVERE, null, ex);
                }
                cantidadProdtxt.setEditable(false);
                prodAnadidos.setVisible(true);
                prodAnadidosnum.setVisible(true);
                productosFac.setEnabled(false);

            }

        }

        if (e.getSource() == btnAddProd) {

            limpiarTxt();
            btnCalc.setVisible(true);
            btnAddProd.setVisible(false);
            cantidadProdtxt.setEditable(true);
            actcontProd();
            prodAnadidos.setVisible(false);
            prodAnadidosnum.setVisible(false);
            productosFac.setEnabled(true);
        }

    }

    @Override
    public void itemStateChanged(ItemEvent ev) {

        if (ev.getStateChange() == ItemEvent.SELECTED) {

            if (!"".equals(cantidadProdtxt.getText())) {
                String elemento = productosFac.getSelectedItem().toString();
                calcularTotal();

            } else {
                JOptionPane.showMessageDialog(null, "FAVOR INGRESE LA CANTIDAD DEL PRODUCTO");
            }

        }

    }

    @Override
    public void keyTyped(KeyEvent e) {

        char karakter = e.getKeyChar();

        if (e.getSource() == cantidadProdtxt) {

            if (!(((karakter >= '0') && (karakter <= '9') || (karakter == KeyEvent.VK_BACK_SPACE) || (karakter == KeyEvent.VK_DELETE)))) {
                getToolkit().beep();
                e.consume();
            }

            if (karakter == KeyEvent.VK_BACK_SPACE) { // Si la tecla presionada es "backspace"
                String text = cantidadProdtxt.getText();
                if (text.length() > 0) { // Si hay texto en el campo de texto
                    cantidadProdtxt.setText(text.substring(0, text.length())); // Eliminar el último carácter
                }
            }

        }

    }

    public void actualizarDatosCombo() {

        hilos h1 = new hilos();
        h1.start();

    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

    class hilos extends Thread {

        public void run() {

            try {

                productosFac.removeAllItems();

                File prod = new File("productos.txt");
                FileReader fr = new FileReader(prod);
                BufferedReader br = new BufferedReader(fr);
                String cadena = br.readLine();

                while (cadena != null) {

                    String reg[] = cadena.split(",");
                    productosFac.addItem(reg[1]);
                    cadena = br.readLine();

                }
                br.close();
                fr.close();

            } catch (IOException e) {

            }

         
        }

    }

}


