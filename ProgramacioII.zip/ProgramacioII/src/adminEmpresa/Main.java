package adminEmpresa;

import java.io.IOException;
import java.util.ArrayList;

public class Main {

    static ArrayList<Empleado> listaEmpleado = new ArrayList();

    public static void main(String[] args) throws IOException {

        interfaz inter = new interfaz();
        Thread t = new Thread(inter);
        t.start();

        inter.setVisible(true);

    }
}
