package PracticasAWT;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class deducciones extends Frame implements ActionListener {

    Button btnCalc, btnSalir, btnGuardar, btnMostrar;
    Paneldatos pan;

    public deducciones() {
        this.setLayout(null);
        this.setTitle("Mi primera ventana");
        this.setSize(600, 600);
        this.setBackground(Color.black);
        this.setLocationRelativeTo(this);
        this.addWindowListener(new cerrarVentana());

        btnCalc = new Button("Calcular");
        btnCalc.addActionListener(this);
        btnCalc.setBounds(100, 520, 100, 30);
        add(btnCalc);

        btnSalir = new Button("Salir");
        btnSalir.addActionListener(this);
        btnSalir.setBounds(200, 520, 100, 30);
        add(btnSalir);

        btnGuardar = new Button("Guardar");
        btnGuardar.addActionListener(this);
        btnGuardar.setBounds(300, 520, 100, 30);
        add(btnGuardar);

        btnMostrar = new Button("Mostrar");
        btnMostrar.addActionListener(this);
        btnMostrar.setBounds(400, 520, 100, 30);
        add(btnMostrar);

        pan = new Paneldatos();
        add(pan);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnSalir) {
            System.exit(0);
        }
        if (e.getSource() == btnGuardar) {
            pan.guardarDatos();
            pan.limpiarPantalla();

        }
        deducciones ded = new deducciones();
        if (e.getSource() == btnMostrar) {
            pan.mostrarDatos();

        }
    }

    public class cerrarVentana extends WindowAdapter {

        @Override
        public void windowClosing(WindowEvent ev) {
            System.exit(0);
        }
    }

}
