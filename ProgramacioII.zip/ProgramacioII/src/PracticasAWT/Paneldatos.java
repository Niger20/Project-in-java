package PracticasAWT;

import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

public class Paneldatos extends JPanel {

    Label lblNomb, lblEdad, lblSal;
    TextField txtNomb, txtEdad, txtSal;

    public Paneldatos() {
        setLayout(null);
        setSize(500, 454);
        this.setLocation(50, 50);
        this.setBackground(Color.LIGHT_GRAY);

        lblNomb = new Label("Nombre: ");
        lblNomb.setBounds(70, 75, 50, 30);
        lblNomb.setBackground(Color.white);
        add(lblNomb);

        txtNomb = new TextField();
        txtNomb.setBounds(150, 75, 200, 55);
        txtNomb.addFocusListener(new validacionDa());
        add(txtNomb);

        lblEdad = new Label("Edad: ");
        lblEdad.setBounds(70, 200, 50, 30);
        lblEdad.setBackground(Color.white);
        add(lblEdad);

        txtEdad = new TextField();
        txtEdad.setBounds(150, 200, 200, 55);
        txtEdad.addFocusListener(new validacionDa());
        add(txtEdad);

        lblSal = new Label("Salario: ");
        lblSal.setBounds(70, 350, 50, 30);
        lblSal.setBackground(Color.white);
        add(lblSal);

        txtSal = new TextField();
        txtSal.setBounds(150, 350, 200, 55);
        txtSal.addFocusListener(new validacionDa());
        add(txtSal);

        this.setBorder(new TitledBorder(new EtchedBorder(), "Datos Empleado"));

    }

    public void guardarDatos() {
        Empleado ep;
        String nombre = txtNomb.getText();
        int edad = Integer.parseInt(txtEdad.getText());
        float salario = Float.parseFloat(txtSal.getText());

        ep = new Empleado(edad, salario, nombre);

        Main.listaEmpleado.add(ep);
    }

    public void limpiarPantalla() {
        txtNomb.setText("");
        txtEdad.setText("");
        txtSal.setText("");

    }

    public void mostrarDatos() {

        for (Empleado emp : Main.listaEmpleado) {

            JOptionPane.showMessageDialog(null, "Edad: " + emp.getEdad() + " Nombre: " + emp.getNombre() + " Salario: " + emp.getSalario() + "\n");

        }

    }

    public boolean esSoloLetras(String cadena) {

        for (int i = 0; i < cadena.length(); i++) {

            char caracter = cadena.toUpperCase().charAt(i);
            int valorASCII = (int) caracter;

            if (valorASCII != 165 && (valorASCII < 65 || valorASCII > 90)) {
                return false;
            }

        }
        return true;
    }

    public class validacionDa extends FocusAdapter {

        @Override
        public void focusLost(FocusEvent f) {

            if (f.getSource() == txtNomb) {
                Paneldatos pan = new Paneldatos();

                String nombre = txtNomb.getText();

                if (pan.esSoloLetras(nombre)) {

                } else {

                    JOptionPane.showMessageDialog(null, "Nombre no valido");
                    txtNomb.setText("");

                }

            }
            if (f.getSource() == txtEdad) {

                try {

                    int Edad;
                    Edad = Integer.parseInt(txtEdad.getText());

                } catch (Exception e) {

                    JOptionPane.showMessageDialog(null, "Edad no valida");
                    txtEdad.setText("");

                }

            }

            if (f.getSource() == txtSal) {

                try {

                    if (txtSal.getText() == null) {

                    } else {

                        float salario;

                        salario = Float.parseFloat(txtSal.getText());

                    }

                } catch (Exception e) {

                    JOptionPane.showMessageDialog(null, "Salario no valido");
                    txtSal.setText("");

                }

            }

        }

    }

}
