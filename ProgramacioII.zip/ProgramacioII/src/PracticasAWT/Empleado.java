
package PracticasAWT;

public class Empleado {
    
    private  int edad;
    private float salario;
    private String nombre;
    
    public Empleado(){
    }
    public Empleado(int edad, float salario, String nombre){
        this.edad= edad;
        this.salario=salario;
        this.nombre=nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public float getSalario() {
        return salario;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    
    
}
