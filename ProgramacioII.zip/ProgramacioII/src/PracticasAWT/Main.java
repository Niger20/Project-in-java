
package PracticasAWT;

import java.util.ArrayList;


public class Main {
    
    static ArrayList<Empleado> listaEmpleado = new ArrayList ();
    
    public static void main(String[] args) {
        
        deducciones ded = new deducciones();
        
        ded.setVisible(true);
        
    }
}
